# vision
Voice assistant

How to use:
1: Download source code.
2: Run start.py
3: Say listen for start listening commands

# Note: you can give voice commands in hindi language also
