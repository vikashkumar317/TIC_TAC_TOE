#command list for browsing
systemcommandset =[['open','msword'],['open','chrome'],['exit'],
['start','mousehover'],['stop','mousehover'],['msword','khole'],
['mousehover','khole'],['mousehover','band','karo'],['chrome','kholo'],
['smapat','karo'],['find','file'],['file','khojo'],['send','mail']]
