from Speechmanager.speech_manager import speech as sp
